# 《剑来·开放世界》Android 项目

这是将现有单文件 HTML 游戏封装成 Android 应用的项目。应用通过 Android WebView 在本地加载游戏资源，游戏无需联网运行；WebView 的 DOM 存储用于保留本机浏览器式存档。

## 如何生成 APK

当前构建环境没有安装 Android SDK/Gradle，因此此处提供的是可导入 Android Studio 的完整项目源码，而不是已经编译好的 APK。

1. 在电脑上安装 Android Studio（建议使用当前稳定版）。
2. 解压本项目 ZIP。
3. 在 Android Studio 中选择 **Open**，打开解压后的 `JianlaiAndroid` 文件夹。
4. 等待 Gradle 同步完成；首次同步需要联网下载 Android Gradle Plugin 和 AndroidX WebKit 依赖。
5. 连接已开启开发者选项与 USB 调试的安卓手机，或启动模拟器。
6. 点击 **Run** 安装试运行；或者选择 **Build > Build APK(s)** 生成 APK。
7. Debug APK 通常位于 `app/build/outputs/apk/debug/app-debug.apk`。

## 在 Android Studio 生成可安装 APK

- 菜单：`Build > Build Bundle(s) / APK(s) > Build APK(s)`
- 若要分发给他人，建议通过 `Build > Generate Signed Bundle / APK` 创建签名 APK。

## 项目说明

- 应用名称：剑来·开放世界
- 包名：`com.jianlai.openworld`
- 最低 Android 版本：Android 6.0（API 23）
- 游戏文件：`app/src/main/assets/index.html`
- 图标：`app/src/main/res/drawable/ic_launcher.xml`
- 本地存档保存在应用 WebView 数据中。清除应用数据或卸载应用可能会删除存档，请先在游戏内保留/导出存档（若该版本提供此功能）。
- 当前是离线 WebView 封装，不是从零重写的原生游戏；后续可再做沉浸式全屏、震动反馈、原生存档备份等优化。
